(function ($) {
	"use strict";

    jQuery(document).ready(function($){

    	// Slicknav
		$('#main-menu').slicknav({
	        closeOnClick: true,
	        label: '',
	        appendTo:'.mobile-menu',
	    });


	    // Header Search Form
		$("#search-modal-btn").on("click", function(e) {
			e.preventDefault();
			$(".search-modal-wrpr").addClass("active");
		});

		$('.search-modal-wrpr .close-icon').on('click', function() {
		  	$(".search-modal-wrpr").removeClass("active");
		});

		var element = document.getElementById("text-roller");
		var text_roller = new TextRoller(element);
		text_roller.start();
        
    });


    jQuery(window).load(function(){

        
    });


}(jQuery));	